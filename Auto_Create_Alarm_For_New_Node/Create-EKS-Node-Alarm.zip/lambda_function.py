import json
import boto3
from botocore.exceptions import ClientError

#多条重复alarm
def check_and_delete_alarm(cloudwatch, ec2, confAlarmNamePrefix, instance_id, instance_status):
    expected_alarm_name = f"{confAlarmNamePrefix}{instance_id}"
    
    try:
        alarms = cloudwatch.describe_alarms(AlarmNames=[expected_alarm_name])
        
        if alarms['MetricAlarms']:
            for alarm in alarms['MetricAlarms']:
                alarm_name = alarm['AlarmName']
                
                if alarm_name == expected_alarm_name and instance_status == 'shutting-down':
                    cloudwatch.delete_alarms(AlarmNames=[alarm_name])
                else:
                    print(f"No matching alarm to delete for event: {instance_status} and instance: {instance_id}")
        else:
            print(f"No alarm found for instance: {instance_id}")
            
    
    except ClientError as e:
        print(f"Error checking/deleting alarm for {instance_id}: {str(e)}")

def create_alarm(cloudwatch, instance_id, confAlarmNamePrefix, confDatapointsToAlarm, confPeriod, confEvaluationPeriods, confAlarmDescription, alarmAction):
    alarm_name = f"{confAlarmNamePrefix}{instance_id}"
    existing_alarm = cloudwatch.describe_alarms_for_metric(
        MetricName='StatusCheckFailed_System',
        Namespace='AWS/EC2',
        Dimensions=[
            {'Name': 'InstanceId', 'Value': instance_id},
        ],
    )
    if not existing_alarm['MetricAlarms']:
        try:
            cloudwatch.put_metric_alarm(
                AlarmName=alarm_name,
                ComparisonOperator='GreaterThanOrEqualToThreshold',
                DatapointsToAlarm=confDatapointsToAlarm,
                MetricName='StatusCheckFailed_System',
                Namespace='AWS/EC2',
                Period=confPeriod,
                EvaluationPeriods=confEvaluationPeriods,
                Statistic='Maximum',
                Threshold=1,
                ActionsEnabled=True,
                AlarmDescription=confAlarmDescription,
                Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}],
                Unit='Count',
                AlarmActions=alarmAction,
            )
        except Exception as e:
            print(f"Error creating alarm for instance {instance_id}: {e}")
            print(f'Error: {str(e)}')

def lambda_handler(event, context):
    confRegion = ""
    confSnsTopic = ''
    confAutoRecovery = ''
    confAlarmDescription = "When system check fails, send alarm info to SNS topic"
    confAlarmNamePrefix = "ec2-eks-hardware-issue-"
    confDatapointsToAlarm = 1
    confPeriod = 60
    confEvaluationPeriods = 1
    alarmAction = [confSnsTopic]
    
    #从 eventbridge 里获取 instance ID, status
    instance_id = event['detail']['instance-id']
    print(f'instance id: {instance_id}')
    instance_status = event['detail']['state']
    print(f'instance status: {instance_status}')
    #end

    ec2 = boto3.client('ec2', region_name=confRegion)
    cloudwatch = boto3.client('cloudwatch', region_name=confRegion)
    
    if instance_status == 'pending': #include creating or starting
        response = ec2.describe_instances(InstanceIds=[instance_id])
        # 遍历实例列表
        for reservation in response['Reservations']:
            for instance in reservation['Instances']:
                # 检查实例是否包含指定的标签键
                tags = {tag['Key']: tag['Value'] for tag in instance.get('Tags', [])}
                if 'eks:cluster-name' in tags:
                    print("New Node add to EKS Cluster,create alarm!")
                    create_alarm(cloudwatch,instance_id,confAlarmNamePrefix,confDatapointsToAlarm, confPeriod, confEvaluationPeriods, confAlarmDescription, alarmAction)
                elif 'aws:elasticmapreduce:job-flow-id' in tags:
                    print("EMR")
                else:
                    print("VM")
    
    elif instance_status == 'shutting-down':
        print("Instance Terminated!")
        check_and_delete_alarm(cloudwatch, ec2, confAlarmNamePrefix, instance_id, instance_status)
    
    return {"status": "success", "message": "Processing complete"}
